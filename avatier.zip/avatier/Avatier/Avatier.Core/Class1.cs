﻿namespace Avatier.Core
{
    public class Class1
    {

    }
}
