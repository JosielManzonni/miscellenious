# Core Project

The **Core** project defines the domain boundaries of the application.  
It is free from infrastructure concerns or external dependencies.

---

## 📦 Contents

### ✔ Domain
- `User`
- `LdapEntryDto`

### ✔ Interfaces
- `ILdapService`
- `ILdapConnectionFactory`
- `ILogger`

### ✔ Exceptions
- `LdapOperationException`
- `LdapAuthenticationException`

---

## 🎯 Purpose

- Establish system-wide contracts  
- Keep domain independent from infrastructure  
- Guarantee cross-platform portability  
- Allow complete test isolation  

No class inside Core references LDAP libraries.

---

## 📁 Folder Structure

Core/
├── Domain/
│ ├── Entities/
│ │ ├── User.cs
│ │ └── LdapEntryDto.cs
│ └── Exceptions/
│ ├── LdapOperationException.cs
│ └── LdapAuthenticationException.cs
└── Interfaces/
├── ILdapService.cs
├── ILdapConnectionFactory.cs
└── ILogger.cs


---

# 📁 3) INFRA README (`Core.Infra.Ldap/README.md`)

```markdown
# Core.Infra.Ldap – LDAP Implementation

This project contains the **actual LDAP implementation** behind the interfaces defined in Core.

It is fully cross-platform and uses `System.DirectoryServices.Protocols` (SDSP).

---

## 🧩 Components

### ✔ LdapConnectionFactory
Creates connections using:
- host  
- port  
- SSL  
- certificate validation  

Implements:  
`ILdapConnectionFactory`

---

### ✔ LdapConnectionAdapter
Adapter that wraps SDSP’s `LdapConnection`.

Exposes:

- `Bind(dn, password)`
- `Search(baseDn, filter, attributes)`
- `Modify(dn, modifications)`

---

### ✔ LdapService
Implements `ILdapService` from Core.

Supports:

| Operation | Method |
|----------|--------|
| Authenticate (bind) | `AuthenticateAsync` |
| List users | `ListUsersAsync` |
| Modify attributes | `UpdateAttributesAsync` |
| Add user to group | `AddUserToGroupAsync` |
| Remove user from group | `RemoveUserFromGroupAsync` |
| Change password | `ChangePasswordAsync` |

---

## 📁 Folder Structure

Core.Infra.Ldap/
├── LdapService.cs
├── LdapConnectionFactory.cs
└── LdapConnectionAdapter.cs


---

## 🔧 Configuration

Usage example:

```csharp
var factory = new LdapConnectionFactory("ldap.example.com", 636, useSsl: true);
var service = new LdapService(factory, logger);

🧪 Testing Strategy

All public classes in this project use:

dependency inversion

no static calls

pure adapters

This makes them fully testable using:

FakeLdapConnection

FakeFactory

(No real LDAP server needed.)