# LDAP Toolkit – Clean Architecture (Cross-Platform)

This repository delivers a fully cross-platform LDAP management toolkit built using a Clean Architecture approach.  
All code is compatible with **Linux, Windows, macOS**, and does not rely on Windows-only APIs.

---

## 📚 Project Structure

├── Core
│ ├── Domain/
│ └── Interfaces/
│
├── Core.Infra.Ldap
│ ├── LdapService.cs
│ ├── LdapConnectionFactory.cs
│ └── LdapConnectionAdapter.cs
│
├── Cli
│ ├── Program.cs
│ └── Commands/
│
└── Tests
├── LdapServiceTests.cs
├── Fakes/
└── Helpers/


---

## 🧱 Architecture Overview

### 🧠 Core  
Contains Domain models, interfaces, and exceptions.  
Zero platform dependencies.

### 🔌 Infra (Core.Infra.Ldap)  
Implements LDAP operations using:

- `System.DirectoryServices.Protocols`
- clean custom adapters  
- factory abstractions  
- robust error-handling

### 🖥 CLI  
Cross-platform command line client using the Core service.

### 🧪 Tests  
Complete fake LDAP implementation for deterministic testing.

---

## 🔧 Build

dotnet build


---

## ▶️ Run CLI

dotnet run --project Cli


---

## 🧪 Run Tests

dotnet test

---

## 🐳 Optional LDAP Server via Docker

docker run --rm -p 389:389 -p 636:636 osixia/openldap
