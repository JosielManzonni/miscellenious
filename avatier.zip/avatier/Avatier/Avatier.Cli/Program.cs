﻿using Avatier.Core.Domain.Interfaces;
using Avatier.Core.Infra.Ldap;
using Avatier.Core.Infra.Logging;
using Avatier.Infra.Ldap;
using Microsoft.Extensions.DependencyInjection;


class Program
{
    static async Task Main(string[] args)
    {
        var services = new ServiceCollection();

        // Logging
        services.AddSingleton<ILogger, ConsoleLogger>();

        services.AddSingleton<ILdapConnectionFactory>(new LdapConnectionFactory(
            host: "35.94.192.121",
            port: 636,
            useSsl: true,
            acceptAllCertificates: true
        ));


        // LDAP service (constructor matches your implementation)
        services.AddSingleton<ILdapService>(provider =>
            new LdapService(
                factory: provider.GetRequiredService<ILdapConnectionFactory>(),
                logger: provider.GetRequiredService<ILogger>()
            )
        );

        var provider = services.BuildServiceProvider();
        var ldap = provider.GetRequiredService<ILdapService>();
        var logger = provider.GetRequiredService<ILogger>();

        // -------------------------------
        // Authenticate
        // -------------------------------
        string dn = "cn=testAccount1,dc=example,dc=org";
        string password = "testAccount1";

        logger.Info("Authenticating LDAP user...");

        bool authenticated = await ldap.AuthenticateAsync(dn, password);

        if (!authenticated)
        {
            logger.Error("Authentication failed.");
            return;
        }

        logger.Info("Authentication succeeded!");

        // -------------------------------
        // List Users
        // -------------------------------
        var users = await ldap.ListUsersAsync(
            "dc=example,dc=org",
            "(objectClass=inetOrgPerson)"
        );

        foreach (var user in users)
        {
            logger.Info("User: {0} | CN: {1} | Email: {2}",
                user.DistinguishedName,
                user.GivenName,
                user.Email);
        }
    }
}